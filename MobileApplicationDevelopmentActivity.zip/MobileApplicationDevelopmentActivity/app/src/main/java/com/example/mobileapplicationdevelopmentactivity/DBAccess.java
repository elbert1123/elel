package com.example.mobileapplicationdevelopmentactivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBAccess extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "dbStudent";
    static SQLiteDatabase dbStudent;

    public DBAccess(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        dbStudent = getReadableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase dbStudent) {
        String sql;

        sql = "CREATE TABLE tblName (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "firstName TEXT," +
                "lastName TEXT," +
                "course TEXT," +
                "year TEXT)";
        dbStudent.execSQL(sql);

        sql = "CREATE TABLE tblSchoolYear (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "schoolYearStart TEXT," +
                "schholYearEnd TEXT," +
                "semester TEXT," +
                "syId INTEGER)";
        dbStudent.execSQL(sql);

        sql = "CREATE TABLE tblGrades (" +
                "gradeId INTEGER PRIMARY KEY AUTOINCREMENT," +
                "subjectCode TEXT, " +
                "subjectDescription TEXT," +
                "gradeValue TEXT," +
                "syId INTEGER)";
        dbStudent.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase dbStudent, int oldVersion, int newVersion) {
        dbStudent.execSQL("DROP TABLE IF EXISTS tblName");
        dbStudent.execSQL("DROP TABLE IF EXISTS tblShoolYear");
        dbStudent.execSQL("DROP TABLE IF EXISTS tblGrades");
    }


    public void StudentDeleteAll() {
        getReadableDatabase().delete("tblName", null, null);
    }

    public void SchoolYearDeleteAll() {
        getReadableDatabase().delete("tblSchoolYear", null, null);
    }

    public void GradeDeleteAll() {
        getReadableDatabase().delete("tblGrades", null, null);
    }

    public void StudentAdd(student student_info) {

    }

    public void SchoolYearAdd(SchoolYear sy) {
        ContentValues values = new ContentValues();
        values.put("schoolYearStart", sy.SchoolYearStart);
        values.put("schoolYearEnd", sy.SchoolYearEnd);
        values.put("semester", sy.Semester);
        values.put("syId", sy.SchoolYearId);


        getWritableDatabase().insert("tblSchoolYear", null, values);
    }

    public List<SchoolYear> GetSchoolYear() {
        Cursor c = getReadableDatabase().rawQuery("select * from tbhSchoolYear order by schoolYearStart, schoolYearEnd, semester, syId", null);
        List<SchoolYear> schoolYearList = new ArrayList<>();
        SchoolYear sy;

        while (!c.isAfterLast())
        {
            sy = new SchoolYear();

            sy = new SchoolYear();

            sy.SchoolYearStart = c.getString(1);
            sy.SchoolYearEnd = c.getString(2);
            sy.Semester = c.getString(3);
            sy.SchoolYearId = c.getString(4);
            schoolYearList.add(sy);
            c.moveToNext();
        }
        c.close();
        return schoolYearList;


    }
    public void GradeAdd(StudentGrade gr_list)
    {
      ContentValues values = new ContentValues();
      values.put("subjectCode", gr_list.SubjectCode);
      values.put("subjectDescription",gr_list.SubjectDescription);
      values.put("gradeValue", gr_list.GradeValue);
      values.put("syId", gr_list.SyId);

      getWritableDatabase().insert("tblGrades", null,values);
    }
    public List<StudentGrade> GetGrades(int syId)
    {
     Cursor c = getReadableDatabase().rawQuery("select gradeId, subjectCode, subjectDescription, gradeValue, syId from tblGrades" +
             "where syId= '" + syId + "'", null);
     c.moveToFirst();

     List<StudentGrade> gradeList = new ArrayList<>();
     StudentGrade gr_list;
     while (!c.isAfterLast())
     {
         gr_list = new StudentGrade();
         gr_list.Id = c.getInt(0);
         gr_list.SubjectCode = c.getString(1);
         gr_list.SubjectDescription = c.getString(2);
         gr_list.GradeValue = c.getString(3);
         gr_list.SyId = c.getString(4);
         gradeList.add(gr_list);
         c.moveToNext();


    }
    c.close();
     return gradeList;

 }


}


