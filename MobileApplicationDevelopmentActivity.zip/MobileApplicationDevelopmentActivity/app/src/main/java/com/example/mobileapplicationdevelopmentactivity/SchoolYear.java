package com.example.mobileapplicationdevelopmentactivity;

public class SchoolYear
{

    public String SchoolYearId;
    public String SchoolYearStart;
    public String SchoolYearEnd;
    public String Semester;
}