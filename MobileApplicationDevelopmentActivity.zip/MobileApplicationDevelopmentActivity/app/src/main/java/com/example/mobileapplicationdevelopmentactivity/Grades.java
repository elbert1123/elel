package com.example.mobileapplicationdevelopmentactivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Grades extends AppCompatActivity {

    List<SchoolYear> semester;

    RecyclerView rvGrade;


    List<StudentGrade> studentGradeList;

    DBAccess da;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grades);
        da = new DBAccess(this);
        semester = new ArrayList<>();
        semester = PopSchoolYear();

        studentGradeList = new ArrayList<>();
        studentGradeList = GetListofGrade();

//        semester.add("2022-2023 1st Semester");
//        semester.add("2022-2023 2nd Semester");
//        semester.add("2023-2024 1st Semester");
//        semester.add("2023-2024 2nd Semester");

//        ArrayAdapter arr = new ArrayAdapter(this, android.R.layout.simple_spinner_item,semester);
////        arr.setDropDownViewResource(android.R.layout.simple_spinner_item);

        SchoolYearSpinnerAdapter spinnerAdapter = new SchoolYearSpinnerAdapter(this, R.layout.school_year_row, semester);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);

        Spinner spinner = findViewById(R.id.spinner);
        TextView txtGradesLabel = findViewById(R.id.textView6);

        spinner.setAdapter(spinnerAdapter);
        rvGrade = findViewById(R.id.rvGrades);

        GradeRecycleViewAdapter gr = new GradeRecycleViewAdapter();

        RecyclerView.LayoutManager l = new LinearLayoutManager(getApplicationContext());
        l.setItemPrefetchEnabled(true);
        rvGrade.setLayoutManager(l);
        rvGrade.setItemAnimator(new DefaultItemAnimator());
        rvGrade.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));

        gr.grade_list = studentGradeList;
        rvGrade.setAdapter(gr);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SchoolYear selectedItem = semester.get(position);

                // Check if selectedItem and its SchoolYearId are not null
                if (selectedItem != null && selectedItem.SchoolYearId != null) {
                    studentGradeList.clear();

                    // Parse the SchoolYearId to an integer
                    try {
                        int schoolYearId = Integer.parseInt(selectedItem.SchoolYearId);
                        gr.grade_list = da.GetGrades(schoolYearId);
                        gr.notifyDataSetChanged();
                    } catch (NumberFormatException e) {
                        // Handle the case where SchoolYearId cannot be parsed to an integer
                        // For example, display an error message or take appropriate action
                        e.printStackTrace();
                    }
                } else {
                    // Handle the case where the selected item or its SchoolYearId is null
                    // For example, display an error message or take appropriate action
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Handle the case where nothing is selected in the spinner
            }
        });





    }

    private List<SchoolYear> PopSchoolYear() {
        List<SchoolYear> schoolYearList = new ArrayList<>();

        SchoolYear schoolYear;

        schoolYear = new SchoolYear();
        schoolYear.SchoolYearStart = "2022";
        schoolYear.SchoolYearEnd = "2023";
        schoolYear.Semester = "1st Semester";

        schoolYearList.add(schoolYear);

        schoolYear = new SchoolYear();
        schoolYear.SchoolYearStart = "2022";
        schoolYear.SchoolYearEnd = "2023";
        schoolYear.Semester = "2nd Semester";

        schoolYearList.add(schoolYear);

        schoolYear = new SchoolYear();
        schoolYear.SchoolYearStart = "2023";
        schoolYear.SchoolYearEnd = "2024";
        schoolYear.Semester = "1st Semester";

        schoolYearList.add(schoolYear);

        schoolYear = new SchoolYear();
        schoolYear.SchoolYearStart = "2023";
        schoolYear.SchoolYearEnd = "2024";
        schoolYear.Semester = "2nd Semester";

        schoolYearList.add(schoolYear);

        return schoolYearList;
    }

    private List<StudentGrade> GetListofGrade() {

        List<StudentGrade> list = new ArrayList<>();

        StudentGrade studentGrade;

        studentGrade = new StudentGrade();
        studentGrade.Id = 1;
        studentGrade.SubjectCode = "IT 101";
        studentGrade.SubjectDescription = "Database Management";
        studentGrade.GradeValue = "2.00";
        studentGrade.SyId = "1";

        list.add(studentGrade);

        studentGrade = new StudentGrade();
        studentGrade.Id = 2;
        studentGrade.SubjectCode = "IT 102";
        studentGrade.SubjectDescription = "System Analysis and Design";
        studentGrade.GradeValue = "1.50";
        studentGrade.SyId = "2";

        list.add(studentGrade);

        return list;

    }
}

