package com.example.mobileapplicationdevelopmentactivity;

import android.widget.TextView;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GradeRecycleViewHolder extends RecyclerView.ViewHolder
{
    final TextView code;
    final TextView des;
    final TextView val;

    public GradeRecycleViewHolder(@NonNull View itemView) {
        super(itemView);

        code = itemView.findViewById(R.id.txtsubjectcode);
        des = itemView.findViewById(R.id.txtSubjectDescription);
        val = itemView.findViewById(R.id.txtSubjectGrade);
    }
}
