package com.example.mobileapplicationdevelopmentactivity;

public class StudentGrade
{

    public int Id;
    public String SubjectCode;
    public String SubjectDescription;
    public String GradeValue;
    public String SyId;
}
