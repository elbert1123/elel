package com.example.mobileapplicationdevelopmentactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button button=findViewById(R.id.btnLogin);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });

        Button button1 = findViewById(R.id.btnGrades);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Grades.class);
                startActivity(intent);
            }
        });

        Button button2 = findViewById(R.id.btnSchedule);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, Schedule.class);
                startActivity(intent);
            }
        });

        DBAccess dbAccess = new DBAccess(this);

        ProgressBar pb = new ProgressBar(this);

        WebApi api = new WebApi(this,"212612", "01112003",new ProgressBar(this));
        api.execute();
    }
}