package com.example.mobileapplicationdevelopmentactivity;

public class student {
    public String LastName ;
    public String FirstName;
    public String Course;
    public String Year;
}
